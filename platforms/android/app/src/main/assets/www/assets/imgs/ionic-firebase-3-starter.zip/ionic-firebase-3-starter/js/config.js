angular.module('starter.configs', [])

.constant("CONFIG", {
  "FIREBASE_API": '',
  "FIREBASE_AUTH_DOMAIN": '',
  "FIREBASE_DB_URL": '',
  "FIREBASE_STORAGE": '',
  "MESSAGE_SENDER_ID": ''
});